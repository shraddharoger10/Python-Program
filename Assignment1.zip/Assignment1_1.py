#1.Write a program which contains one function named as Fun(). That function should display
#“Hello from Fun” on console.

def fun():
    print("Hello from Fun")

def main():
    fun()


if __name__ == '__main__':
    main()