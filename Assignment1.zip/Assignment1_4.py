#4.Write a program which display 5 times Marvellous on screen.
#Output : Marvellous
#         Marvellous
#         Marvellous
#         Marvellous
#         Marvellous

def Display():
    for i in range(0,5,1):
        print("Marvellous")

def main():
    Display()

if __name__ == '__main__':
    main()